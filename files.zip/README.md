# vocab-ladder

A self-contained vocabulary-training feature built around one idea: the bottleneck at B1→B2 is not *recognising* more words, it's *using* the words you half-know. So the whole feature is engineered to push items from passive recognition into active production, then lock them in with spaced repetition.

It ships as a single React component (`<VocabLadder />`) with a swappable storage backend, its own scoped styles, and a small design kit. It has no runtime dependencies beyond React.

---

## The method

Three moves, run daily in order. The pedagogy maps one-to-one onto the UI.

**1 · Learn (recognition intake).** The learner meets pre-authored words — word, its collocation, a short gloss. Pure reading; zero typing. They're nudged to guess meaning from the collocation before flipping the card, mimicking how meaning is first inferred from context rather than memorised from a definition.

**2 · Bridge (the passive→active converter).** For each word the learner writes *one original sentence* in their own context, keeping the collocation intact. This is the single highest-value step and the only place the learner types anything substantial. Recognising a word in someone else's sentence doesn't make it usable; producing it in your own does. Bridging is **optional per-item** — a learner can skip it and still review the word by definition — so a low-energy day never blocks the queue.

**3 · Review (spaced retrieval).** Each bridged sentence becomes a *cloze* — the learner's own sentence with the target word blanked. This forces production-style recall, not the weaker recognition recall of a word→definition flashcard. Reviews are scheduled at **1 · 3 · 7 · 14 · 30 days**; clearing all five graduates the item to **owned**. The spacing compresses the dozen-or-so spaced encounters a word needs into a few weeks instead of the years of incidental exposure a child gets.

### Why collocations, not bare words

The B1→B2 jump is largely about *combining* words correctly — "pose a threat," "curb emissions," "raise awareness." Every item carries its collocate, the cloze keeps the collocation whole, and the review hint masks only the target inside the phrase. This trains the exact lexical-range competence that production tasks reward.

---

## Two roles

The feature has a built-in mode toggle, because the person curating words and the person learning them are usually different people.

**Teach.** Bulk-import a curated list (one paste, hundreds of items), preview what's new vs. duplicate, and manage the deck. Authoring is deliberately a teacher/coach job: a fluent curator filters for quality and supplies the right collocations, which removes that burden from the learner.

**Learn.** Today dashboard + the three move-tabs. The learner never authors words; their only input is the one bridge sentence. This was a deliberate friction cut — every manual step that *isn't* the bridge was removed, because friction anywhere else is pure cost, while the bridge sentence *is* the learning.

---

## Import format

One item per line. Fields separated by `|` (or tab / semicolon; comma is used only as a fallback so definitions may safely contain commas). Order: **word | collocate | definition | context**. Only the word is required. `#` lines are comments.

```
# B2 — environment
mitigate | mitigate the impact | to make less severe | Trees mitigate the impact of heat.
pose      | pose a threat       | to present a danger
curb      | curb emissions
resilient
```

The deck round-trips: the Deck tab's **Copy / export** emits exactly this format, so it doubles as backup and as a way to move a deck between instances.

---

## Data model

One persisted entity — `VocabItem[]`. Each item folds together the authored content and the learner's progress:

| Field | Owner | Meaning |
|---|---|---|
| `word`, `collocate`, `definition`, `context` | author | the curated content |
| `sentence`, `cloze` | learner | the bridge and its derived cloze |
| `seen`, `bridged` | learner | progress flags |
| `stage`, `nextReview` | learner | SRS scheduling state |

> Authored content and learner progress live in the same record here for simplicity. In a multi-learner CMS deployment you'll usually want to split them — see `INTEGRATION.md`, "Decks as content vs. progress as user data."

---

## Architecture

```
src/
├── index.ts                    Public API (mount point + low-level exports)
├── types.ts                    VocabItem, ParsedItem, ParseResult
├── design/
│   ├── tokens.css              ← source of truth for colours + fonts
│   ├── theme.ts                  TS mirror of the tokens
│   └── tailwind-theme.css        optional Tailwind v4 @theme mapping
├── lib/
│   ├── srs.ts                  spacing schedule, grading, queue selectors
│   └── text.ts                 cloze, word-masking, bulk parse/serialize
├── storage/
│   └── adapter.ts              StorageAdapter interface + Local/Memory impls
├── hooks/
│   └── useVocabStore.ts        state + all domain mutations
└── components/
    ├── VocabLadder.tsx         shell, mode/tab routing, Today, Stats
    ├── styles.css              scoped, vt-prefixed; reads design tokens
    ├── learner/                Learn · Bridge · Review
    └── teacher/                Import · Deck
```

Design principles:

- **Logic is pure and dependency-free.** `lib/srs.ts` and `lib/text.ts` are plain functions, unit-testable without React or a DOM.
- **One state owner.** `useVocabStore` holds the deck and every mutation; components are presentational and take callbacks.
- **Storage is the only seam.** Persistence happens exclusively through `StorageAdapter`. Nothing else touches the outside world — which is what makes dropping this into a CMS a one-interface job.
- **Styles can't leak.** All CSS is scoped under `.vt-root` and `vt-`-prefixed, reading colours/fonts from CSS variables so the host can retheme without touching component code.

---

## Design kit

A warm, editorial "paper & ink" palette with a forest-green accent — calm and low-stimulation, appropriate for a focused study tool.

| Token | Hex | Role |
|---|---|---|
| `--vl-paper` | `#f4f1ea` | page background (warm cream) |
| `--vl-paper-2` | `#ebe6da` | cards / raised surfaces |
| `--vl-line` | `#d8d2c4` | hairline borders |
| `--vl-ink` | `#1a1916` | primary text (warm near-black) |
| `--vl-soft` | `#7d7768` | secondary text |
| `--vl-accent` | `#3d5a3d` | accent, focus, "owned" |
| `--vl-accent-soft` | `#e3ebe1` | accent tint |
| `--vl-miss` | `#9a4d3f` | "missed" / destructive (terracotta) |

Type: **Fraunces** (display — headings and the words themselves) paired with **Newsreader** (body — prose and UI). Both are serifs; the pairing leans literary rather than app-generic.

The tokens exist in three synced forms so the kit travels: `tokens.css` (CSS variables, the source of truth), `theme.ts` (a typed object for JS/canvas use), and `tailwind-theme.css` (a Tailwind v4 `@theme` block to expose `bg-paper`, `text-ink`, `font-display`, etc. as utilities).

---

## Quick start (standalone)

```tsx
import { VocabLadder } from "vocab-ladder";

export default function App() {
  return <VocabLadder />; // defaults to namespaced localStorage
}
```

Fonts (either `@import` in your CSS or self-host — see `INTEGRATION.md`):

```css
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&family=Newsreader:ital,opsz@0,6..72;1,6..72&display=swap');
```

For wiring into an existing CMS — routing, per-user storage, decks-as-content, font self-hosting, style isolation — see **`INTEGRATION.md`**.
