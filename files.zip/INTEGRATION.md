# Integrating vocab-ladder into your CMS

This is a guide for adding vocab-ladder to an existing project as a feature, not a standalone app. It assumes a **React + TypeScript + Vite/Tailwind v4** host, since that's the most common case; where your CMS differs (non-React, or a headless backend), the decision points are flagged explicitly.

The feature was built so that exactly **one** thing depends on your environment: persistence. Everything else — logic, state, UI, styling — is self-contained. So most of this document is about that one seam, plus the smaller concerns of routing, fonts, and style isolation.

---

## TL;DR — the three decisions

1. **Storage.** Implement a `StorageAdapter` against your backend (or start with the bundled `LocalStorageAdapter` and swap later). This is the only required integration work.
2. **Identity.** If your CMS has users, namespace each learner's progress by user id. One line in the adapter.
3. **Content ownership.** Decide whether vocab decks are *authored CMS content* (shared, versioned) or *per-user private data*. This determines whether you split the data model — and it's the only decision that might change more than the adapter.

Everything below expands these. A phased path at the end lets you ship in an afternoon and harden later.

---

## 1. Mounting the feature

The entire feature is one component:

```tsx
import { VocabLadder } from "@/features/vocab-ladder";

<VocabLadder adapter={myAdapter} initialMode="learn" />
```

**React-based CMS** (Next.js, Remix, a Vite SPA, a custom React admin): add a route/page and render `<VocabLadder />`. Done. If you use Next's app router, mark the page `"use client"` — the component is interactive and uses hooks/effects.

**Non-React CMS** (WordPress, a PHP/Laravel CMS, a server-rendered Rails app): mount it as a React island. Pick a container element and hydrate just this widget:

```tsx
import { createRoot } from "react-dom/client";
import { VocabLadder } from "vocab-ladder";
import { ApiAdapter } from "./api-adapter";

const el = document.getElementById("vocab-ladder");
if (el) {
  createRoot(el).render(
    <VocabLadder adapter={new ApiAdapter("/api", { /* auth headers */ })} />
  );
}
```

An `<iframe>` is the last-resort fallback if your CMS makes script injection painful, but it costs you the shared session and shared theming, so prefer the island.

---

## 2. Storage — the one seam that matters

All persistence flows through this interface (`src/storage/adapter.ts`):

```ts
export interface StorageAdapter {
  load(): Promise<VocabItem[]>;
  save(items: VocabItem[]): Promise<void>;
}
```

It's intentionally async even though the bundled `LocalStorageAdapter` is synchronous, so moving to the network later changes nothing in the calling code.

### Server / CMS-backed adapter

```ts
import type { StorageAdapter, VocabItem } from "vocab-ladder";

export class ApiAdapter implements StorageAdapter {
  constructor(private base: string, private headers: HeadersInit) {}

  async load(): Promise<VocabItem[]> {
    const res = await fetch(`${this.base}/vocab`, { headers: this.headers });
    return res.ok ? ((await res.json()) as VocabItem[]) : [];
  }

  async save(items: VocabItem[]): Promise<void> {
    await fetch(`${this.base}/vocab`, {
      method: "PUT",
      headers: { ...this.headers, "Content-Type": "application/json" },
      body: JSON.stringify(items),
    });
  }
}
```

> **Save granularity.** `save()` currently writes the whole deck on every mutation — fine for localStorage and for decks up to a few hundred items. On a network backend that's a chatty `PUT` of the full array per card graded. Two easy hardenings, in order of effort:
> 1. **Debounce** writes in the adapter (collect for ~500 ms, then flush). Zero changes elsewhere.
> 2. **Per-item PATCH.** If you want true row-level writes, change the store to call an item-level mutation; the seam is small but it does touch `useVocabStore`. Only worth it for large decks or high-frequency review sessions.

### Per-user namespacing (identity)

If your CMS has authenticated users, scope storage by user so two learners don't share a deck:

```ts
// localStorage: pass a user-scoped key
new LocalStorageAdapter(`vocab-ladder:items:${userId}`);

// API adapter: scope the path or rely on the session cookie server-side
new ApiAdapter(`/api/users/${userId}`, authHeaders);
```

Pull `userId` from whatever session your CMS already exposes; the feature doesn't need its own auth.

---

## 3. Decks as content vs. progress as user data

This is the one design decision that can push beyond the adapter, so decide it deliberately.

The bundled model stores authored fields (`word`, `collocate`, `definition`, `context`) and learner progress (`sentence`, `cloze`, `seen`, `bridged`, `stage`, `nextReview`) in the **same** `VocabItem`. That's perfect for:

- a single learner (your friend's case), or
- a teacher who hand-imports a personal list per learner.

It's the *wrong* shape once you have **one authored deck consumed by many learners** — because the deck content and each learner's progress would be tangled in one record.

### When you have many learners on shared decks

Split into two stores:

- **Deck = CMS content.** Model `{ word, collocate, definition, context }` as a content type in your CMS (a "Vocabulary Deck" with item children). Authors curate and version it through the CMS's normal editing UI; the Import tab becomes optional (bulk seeding) rather than the primary authoring path.
- **Progress = per-user data.** Store only `{ itemId, sentence, cloze, seen, bridged, stage, nextReview }` keyed by `(userId, deckId)`.

Then your adapter's `load()` joins them — fetch the deck content, left-join the user's progress, and hand the merged `VocabItem[]` to the component. `save()` writes back only the progress fields. The component never knows the difference; this is still "just an adapter," it's only a smarter one.

Recommendation: don't build the split until you actually have multiple learners. The merged model is simpler and the migration is contained to the adapter when you need it.

---

## 4. Styling & theme isolation

All component CSS is scoped under `.vt-root` and prefixed `vt-`, and every colour/font is a CSS variable from `design/tokens.css`. Practical consequences:

- **It won't leak into, or be broken by, your CMS styles** in normal cases. The prefix + scope avoids the usual collisions.
- **Tailwind coexistence.** The feature does *not* use Tailwind internally, so it won't fight your host's Tailwind v4 build. Import order doesn't matter for correctness. If you want to *build adjacent UI* in the same palette, add `design/tailwind-theme.css` after `@import "tailwindcss";` to expose `bg-paper`, `text-ink`, `font-display`, etc.
- **Retheming.** Override the `--vl-*` variables in a wrapper to match your CMS without editing component code:
  ```css
  .my-cms-vocab-wrapper .vt-root {
    --vl-accent: #2b4c7e;        /* your brand */
    --vl-font-display: "Your Display Font", serif;
  }
  ```
- **Hard isolation (only if needed).** If your CMS has aggressive global resets that still bleed in, wrap the mount in a shadow DOM and inject `tokens.css` + `styles.css` into the shadow root. Usually unnecessary; reach for it only if you see breakage.

---

## 5. Fonts

The feature expects **Fraunces** and **Newsreader**. Two options:

- **Quick:** `@import` the Google Fonts URL (in `README.md`). Simplest; adds an external request and a brief FOUT.
- **Recommended for a CMS:** self-host. Download the two families, serve them from your asset pipeline, and declare `@font-face` rules. No third-party request, no layout shift, and it works behind a firewall/offline. The component only references them via `--vl-font-display` / `--vl-font-body`, so once the faces are available the feature picks them up with no code change.

If you'd rather use your CMS's existing fonts, just point those two variables at them — but the literary serif pairing is doing real work for the tool's calm feel, so prefer keeping at least the display face.

---

## 6. Build & dependencies

- **Peer deps:** React ≥18, React-DOM ≥18. Nothing else at runtime.
- **TypeScript:** strict-mode clean; ships its own `.d.ts` via source types.
- **CSS imports:** `VocabLadder.tsx` imports `tokens.css` and `styles.css` directly, so any bundler with CSS support (Vite, Next, webpack) picks them up. If your CMS forbids component-level CSS imports, remove those two import lines and include the stylesheets through your normal pipeline instead.
- **Tree-shaking:** `package.json` marks CSS as the only side-effectful files, so unused low-level exports drop out.

---

## 7. Suggested phased rollout

Low-risk, each phase independently shippable:

**Phase 1 — drop-in (an afternoon).** Mount `<VocabLadder />` with the default `LocalStorageAdapter`. Fully functional immediately, no backend. Good for piloting with one or a few learners. Risk: data is per-browser and not backed up (the export button is the mitigation).

**Phase 2 — persistence (when it needs to survive).** Implement `ApiAdapter` against a single endpoint that stores a JSON blob per user. Namespace by `userId`. Now progress survives across devices and clears the "it's tied to one browser" caveat. No data-model change.

**Phase 3 — content split (only with many learners on shared decks).** Promote decks to a CMS content type, move progress to per-user records, and make the adapter join them. Authors curate through the CMS; learners just learn. This is the only phase that touches the data model, and even then only inside the adapter.

Most deployments stop at Phase 2.

---

## 8. Testing notes

The logic worth testing is already isolated and pure:

- `lib/srs.ts` — `grade`, `dueAt`, `isOwned`, and the queue selectors. Deterministic; pass a fixed `at` timestamp to the selectors for stable tests.
- `lib/text.ts` — `makeCloze` (incl. the inflection fallback), `hideWord`, `parseBulk` ↔ `serializeDeck` round-trip, comma-in-definition handling.

These need no DOM. Use `MemoryAdapter` for any test that exercises `useVocabStore` end-to-end without persistence.

---

## Checklist

- [ ] Mount `<VocabLadder />` on a route (or as an island in a non-React CMS)
- [ ] Implement `StorageAdapter` for your backend (or ship Phase 1 with `LocalStorageAdapter`)
- [ ] Namespace storage by `userId` if you have authenticated users
- [ ] Decide deck-as-content vs. merged model (defer the split until multi-learner)
- [ ] Self-host or `@import` Fraunces + Newsreader
- [ ] Confirm no style collisions; retheme `--vl-*` if you want brand alignment
- [ ] (Optional) debounce or PATCH-ify `save()` for large decks
